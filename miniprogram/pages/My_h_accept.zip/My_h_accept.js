// pages/My_h_accept/My_h_accept.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    dataList:[]
  },
  
  getData(num=5,page=0){

    db.collection("my_accept").skip(page).limit(num).get({
      success:res=>{
        //console.log(res.data)
        var oldData=this.data.dataList
        //console.log(oldData)
        var newData=oldData.concat(res.data)
        //console.log(newData)
        this.setData({
          
          dataList:newData
          //dataList:res.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getData(5,0);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})